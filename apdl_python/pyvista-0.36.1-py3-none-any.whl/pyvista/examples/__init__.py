"""Examples routines."""

from pyvista.examples.downloads import *
from pyvista.examples.examples import *
from . import gltf
from . import hdr
from . import vrml
