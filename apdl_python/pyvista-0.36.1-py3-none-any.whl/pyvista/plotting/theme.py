"""Here for backwards compatibility with pyvistaqt."""

from pyvista import rcParams  # noqa

from .tools import parse_color  # noqa
