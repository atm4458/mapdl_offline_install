#!/usr/bin/env python

line_font_pattern = {None : 'Default', 0 : 'Default', 1 : 'Solid',
        2 : 'Dashed', 3 : 'Phantom', 4 : 'Centerline', 5 : 'Dotted'}

