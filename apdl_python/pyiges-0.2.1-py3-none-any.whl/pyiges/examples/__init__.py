import os
filepath = os.path.dirname(__file__)
impeller = os.path.join(filepath, 'impeller.igs')
sample = os.path.join(filepath, 'sample.igs')
