from pyiges._version import __version__
from pyiges.iges import Iges, read
