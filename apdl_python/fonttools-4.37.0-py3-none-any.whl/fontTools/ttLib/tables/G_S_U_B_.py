from .otBase import BaseTTXConverter


class table_G_S_U_B_(BaseTTXConverter):
	pass
